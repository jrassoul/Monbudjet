# Monbudget

* ### Nom
  Monbudget




* ### Auteurs
  Juba RASSOUL (jubarassoul99@gmail.com), 
  Gauthier portefaix (portefaixgauthier@gmail.com)


* ### Description

L'application a pour but d'aider l'utisateur à avoir un meilleur control de son budget en traçant ses entrées et sorties d'argent. Elle fournit ainsi le bilan financier d'une journée, semaine, mois ou année, tout cela dans une interface simple et intuitive.

Aussi, l'application peut emettre des notifications afin de rappeler à l'utilisateur une dépense prévu.

Une telle application est utile en ce sens qu'elle permet à l’utilisateur de s’avoir si sa solde a était négative ou positive durant le mois. Dans le premier cas, l'utilisateur pourrait trouver le moyen de faire des économies en diminuant ces dépenses. Dans le cas d'un solde positive, 

* ### Note

* ### Activities
    FabAddDialog
    MainActivity
    TransactionActivity
    TransactionInfoDialog
    
    inent 
    activitySwitcher
    startService
    
    
    
    

Cette application a été réalisé dans le cadre du cours d'Android à l'université de paris cergy 

